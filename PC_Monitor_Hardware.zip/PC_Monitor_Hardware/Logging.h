#ifndef __LOGGING_H__
#define __LOGGING_H__

struct EVENT
{
	
};

#endif