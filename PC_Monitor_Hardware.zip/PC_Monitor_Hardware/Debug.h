#ifndef __DEBUG_H__
#define __DEBUG_H__

#define USE_HARDWARE

#define DEBUG_1
#define DEBUG_2
#define DEBUG_3

#endif
